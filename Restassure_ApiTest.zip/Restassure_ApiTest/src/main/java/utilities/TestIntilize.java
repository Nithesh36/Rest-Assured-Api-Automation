package utilities;

import utilities.RestAssureExtension;

public class TestIntilize {
    RestAssureExtension restAssureExtension=new RestAssureExtension();
}
